public class Sample4
{
	public static void main(String[] args)
	{
		int[] arr={97,69,86,122,111};
		int arr_len=arr.length;

		for(int a:arr)
			System.out.print(((char)a)+" ");
	}
}
