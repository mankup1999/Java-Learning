create table dept
(
dept_id number(7) primary key,
dept_name varchar2(20)
);