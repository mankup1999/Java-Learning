insert into dept values
(10,'Accounts');

insert into dept values
(null,'IT');

insert into dept values
(20,'IT');

insert into dept values
('A1','Accounts');

insert into dept values
(30,'Accounts');

select * from dept;