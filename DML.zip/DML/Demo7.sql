update my_employee
set salary=salary*1.1
where department_id=90;