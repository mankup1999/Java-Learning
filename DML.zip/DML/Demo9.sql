delete from my_employee
where first_name like '%man%'
or last_name like '%man%';