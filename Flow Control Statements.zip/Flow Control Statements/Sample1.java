public class Sample1
{
	public static void main(String[] args)
	{
		int a=-10;
		
		if(a>0)
			System.out.println("Positive");
		else if(a<0)
			System.out.println("Negative");
		else
			System.out.println("Zero");
	}
}
