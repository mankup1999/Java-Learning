public class Sample10
{
	public static void main(String[] args)
	{
		for(int i=1;i<=9;i++)
			System.out.print(i+"\t");
		System.out.println(10);
	}
}
