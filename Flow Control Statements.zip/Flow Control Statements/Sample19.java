public class Sample19
{
	public static void main(String[] args)
	{
		int count=0;
		int x=2*3*5;
		while(count++<5)
		{
			System.out.println(x*count);
		}
	}
}
