package wipro;

public class Demo1 {
	public String concat(String a,String b) {
		return a+b;
	}

}
