public class Sample1
{
	public static void main(String[] args)
	{
		String msg=args[0]+" Technologies "+args[1];
		System.out.println(msg);
	}
}
