public class Sample2
{
	public static void main(String[] args)
	{
		String msg="Welcome "+args[0];
		System.out.println(msg);
	}
}
