public class Sample3
{
	public static void main(String[] args)
	{
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int sum=a+b;
		String msg="The sum of "+a+" and "+b+" is "+sum;
		System.out.println(msg);
	}
}
