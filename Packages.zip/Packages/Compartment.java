package com.wipro.automobile.ship;

class Compartment
{
	double height;
	double width;
	double breadth;
}
