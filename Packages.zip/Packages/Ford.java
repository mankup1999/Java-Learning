package com.automobile.FourWheeler;

import com.automobile.Vehicle;

public class Ford extends Vehicle
{
	public int speed()
	{
		return 400;
	}
	public int tempControl()
	{
		return 4000;
	}
}
