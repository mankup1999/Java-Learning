package com.automobile.twowheeler;

import com.automobile.Vehicle;

public class Hero extends Vehicle
{
	public int getSpeed()
	{
		return 100;
	}
	public void radio()
	{
		System.out.println("Hero:radio");
	}
}
