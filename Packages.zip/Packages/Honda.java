package com.automobile.twowheeler;

import com.automobile.Vehicle;
public class Honda extends Vehicle
{
	public int getSpeed()
	{
		return 150;
	}
	public void cdplayer()
	{
		System.out.println("Honda:cdplayer");
	}
}
