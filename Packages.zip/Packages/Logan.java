package com.automobile.FourWheeler;

import com.automobile.Vehicle;

public class Logan extends Vehicle
{
	public int speed()
	{
		return 200;
	}
	public int gps()
	{
		return 2000;
	}
}
