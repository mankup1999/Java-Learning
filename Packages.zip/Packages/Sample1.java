
import test.Foundation;

public class Sample1
{
	public static void main(String[] args)
	{
		Foundation obj=new Foundation();
		int var1=obj.var1;
		int var2=obj.var2;
		int var3=obj.var3;
		int var4=obj.var4;
	}
}
