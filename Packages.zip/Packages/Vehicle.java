package com.automobile;

public class Vehicle
{
	public String getModelName()
	{
		return("Vehicle:getModelName");
	}
	public String getRegistrationNumber()
	{
		return("Vehicle:getRegistrationNumber");
	}
	public String getOwnerName()
	{
		return("Vehicle:getOwnerName");
	}
}
