SELECT employee_id AS "Emp #",
        last_name AS Employee,
        job_id AS Job,
        hire_date AS "Hire Date" 
    FROM employees;