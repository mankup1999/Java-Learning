    
SELECT last_name||', '||job_id AS "Employee and Title"
    FROM employees;