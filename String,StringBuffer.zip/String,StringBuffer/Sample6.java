public class Sample6
{
	public static void main(String[] args)
	{
		String a="hi";
		String b="hello";

		if(a.length()<b.length())
			System.out.println(a+b+a);
		else
			System.out.println(b+a+b);
	}
}
