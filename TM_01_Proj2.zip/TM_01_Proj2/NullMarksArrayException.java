
package com.mile1.exception;

public class NullMarksArrayException extends Exception
{
	//Implementing toString function as described
	public String toString()
	{
		return "NullMarksArrayException occured";
	}
}
