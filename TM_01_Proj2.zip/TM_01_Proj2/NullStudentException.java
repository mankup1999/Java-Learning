
package com.mile1.exception;

public class NullStudentException extends Exception
{
	//Implementing toString function as described
	public String toString()
	{
		return "NullStudentException occured";
	}
}
