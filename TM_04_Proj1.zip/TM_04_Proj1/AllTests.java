package Project;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ InterestCalculatorTest1.class, InterestCalculatorTest2.class, InterestCalculatorTest3.class, VideoLauncherTest.class })
public class AllTests {

}
